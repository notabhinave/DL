import tensorflow as tf

# Set the path to your image directory
image_dir = "path/to/images"

# Set parameters for split
batch_size = 32
img_size = (224, 224)
validation_split = 0.2  # 20% of data for validation/test

# Load training dataset
train_dataset = tf.keras.utils.image_dataset_from_directory(
    image_dir,
    labels="inferred",
    label_mode="int",
    batch_size=batch_size,
    image_size=img_size,
    validation_split=validation_split,
    subset="training",
    seed=123  # Set a random seed for reproducibility
)

# Load validation/testing dataset
test_dataset = tf.keras.utils.image_dataset_from_directory(
    image_dir,
    labels="inferred",
    label_mode="int",
    batch_size=batch_size,
    image_size=img_size,
    validation_split=validation_split,
    subset="validation",
    seed=123
)
